<!DOCTYPE html>
<html>
	<head>
		<title>Log In</title>
		<meta charset="utf-8">
		<meta http-equiv="refresh" content="3;url=index.html" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	</head>
	<body style="background-color:#4d94ff">
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				<h1>Sorry!!</h1>
				</br>
				<h3>Your username or password is invalid.</h3>
				<h4>You'll be directed to login page within 3 seconds.</h4>
			</div>
			<div class="col-md-4"></div>
		</div>
	</body>
</html>